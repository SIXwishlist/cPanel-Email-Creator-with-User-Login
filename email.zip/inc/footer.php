      <nav class="navbar navbar-default navbar-fixed-bottom">
            <div class="container">

                <ul class="nav navbar-nav">
                    <li class="active"><a href="cemail.php">Create a Mail Account<span class="sr-only">(current)</span></a></li>
                    <li><a href="changep.php">Change Password</a></li>
                    <li><a href="logout.php">Logout</a></li>

                </ul>
                <p class="navbar-text">Web Solution by iDeacurl</p>
            </div>
        </nav>
    </body></html>