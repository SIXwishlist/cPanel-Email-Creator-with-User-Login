<script type="text/javascript" src="http://www.hotelroyalgrandparadise.com/js/jquery-1.11.1.min.js"></script>
<link href="css/panel.css" type="text/css" rel="stylesheet" />
    <link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
    
</head>